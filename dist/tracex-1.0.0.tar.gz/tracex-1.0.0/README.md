# TraceX

A modern, web-based tool for extracting public and private IP addresses and cryptographic hashes from files and archives. Built with FastAPI and a beautiful frontend, TraceX is designed for digital forensics, threat intelligence, and data analysis workflows.

---

## Features
- Extract public/private IPv4 and IPv6 addresses from text files and archives
- Extract cryptographic hashes (MD5, SHA1, SHA256, SHA512)
- Supports ZIP and TAR.GZ archives
- Multithreaded extraction for speed
- Web-based UI (FastAPI + HTML/CSS)
- SQLite database backend for results
- Downloadable and extensible

---

## Installation

### Option 1: Development Setup (Recommended for Testing)

#### Prerequisites
- Python 3.8+
- pip

#### Quick Start
1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/TraceX.git
   cd TraceX
   ```
2. Create and activate a virtual environment:
   ```sh
   python -m venv .venv
   # On Windows:
   .venv\Scripts\activate
   # On macOS/Linux:
   source .venv/bin/activate
   ```
3. Install dependencies:
   ```sh
   pip install -r requirements.txt
   pip install uvicorn[standard] fastapi
   ```
4. Run the application:
   ```sh
   python -m uvicorn extractor.webapp:app --reload --host 127.0.0.1 --port 55555
   ```
5. Open [http://127.0.0.1:55555](http://127.0.0.1:55555) in your browser

### Option 2: Linux System Installation (Production)

#### Prerequisites
- Linux system with systemd
- Python 3.8+
- Root/sudo access

#### Installation Steps
1. Clone the repository:
   ```sh
   git clone https://github.com/yourusername/TraceX.git
   cd TraceX
   ```
2. Make installation scripts executable:
   ```sh
   chmod +x install.sh uninstall.sh
   ```
3. Run the installer as root:
   ```sh
   sudo ./install.sh
   ```
4. Start the service:
   ```sh
   sudo systemctl start tracex
   ```
5. Access the web interface at [http://127.0.0.1:55555](http://127.0.0.1:55555)

#### Service Management
```sh
# Check service status
sudo systemctl status tracex

# Start the service
sudo systemctl start tracex

# Stop the service
sudo systemctl stop tracex

# Enable auto-start on boot
sudo systemctl enable tracex

# View logs
sudo journalctl -u tracex -f

# Restart service
sudo systemctl restart tracex
```

#### Uninstallation
```sh
sudo ./uninstall.sh
```

### Option 3: Docker Installation (Coming Soon)
```sh
# Pull and run with Docker
docker pull yourusername/tracex
docker run -p 55555:55555 yourusername/tracex
```

---

## Usage
- Upload files or specify a local path via the web UI
- Select extraction options (IPs, hashes, multithreading)
- View and download results
- Sample data is available in the `sample_data/` directory

---

## API Endpoints
- `POST /extract` — Extract IPs and/or hashes from uploaded file or local path
- `GET /` — Serve the frontend
- Static files served at `/static/`

---

## Project Structure
```
TraceX/
  extractor/           # Backend FastAPI app and core logic
  static/              # Frontend HTML/CSS/JS
  sample_data/         # Example files and archives
  sample_data_generator.py  # Script to generate sample data
  requirements.txt     # Python dependencies
  setup.py            # Package configuration
  install.sh          # Linux installation script
  uninstall.sh        # Linux uninstallation script
  tracex.service      # Systemd service file
  README.md            # Project documentation
  .gitignore           # Git ignore rules
```

---

## Troubleshooting

### Common Issues

#### Port Already in Use
If port 55555 is already in use, you can:
- Kill the process using the port: `sudo lsof -ti:55555 | xargs kill -9`
- Or change the port in the command: `--port 8080`

#### Permission Denied
- Ensure you're running the installer with sudo
- Check that the tracex user was created: `id tracex`

#### Service Won't Start
- Check logs: `sudo journalctl -u tracex -f`
- Verify Python dependencies: `pip3 list | grep tracex`
- Check file permissions: `ls -la /opt/tracex`

#### Web Interface Not Accessible
- Verify the service is running: `sudo systemctl status tracex`
- Check firewall settings: `sudo ufw status`
- Try accessing via localhost: `curl http://127.0.0.1:55555`

---

## Contributing
Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.

---

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details. 